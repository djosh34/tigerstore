# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline | 5 | 40739.8 | 12.995 | 21.000 | 18.01 |
| both | 5 | 42160.0 | 13.647 | 20.667 | 18.34 |
| etcd | 5 | 6078.7 | 76.419 | 160.333 | 263.94 |
| peer | 5 | 42968.3 | 12.540 | 20.667 | 18.17 |
| wake | 5 | 41316.8 | 12.647 | 20.667 | 17.94 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
