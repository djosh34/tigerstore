# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline | 5 | 22162.3 | 6.148 | 37.000 | 22.16 |
| both | 5 | 23406.4 | 5.914 | 36.667 | 22.17 |
| etcd | 5 | 4482.0 | 27.921 | 213.000 | 275.20 |
| peer | 5 | 22791.8 | 6.100 | 36.667 | 22.03 |
| wake | 5 | 22650.0 | 6.239 | 37.000 | 22.23 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
