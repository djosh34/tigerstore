# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline | 5 | 24825.7 | 5.697 | 34.547 | 21.91 |
| etcd | 5 | 4856.3 | 25.813 | 200.969 | 275.48 |
| peer | 5 | 24795.2 | 5.659 | 34.261 | 21.89 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
