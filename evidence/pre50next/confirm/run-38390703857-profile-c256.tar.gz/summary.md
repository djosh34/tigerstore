# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline-profile | 5 | 46881.0 | 11.899 | 18.753 | 17.28 |
| etcd-control | 5 | 6531.0 | 70.011 | 152.613 | 264.26 |
| peer-profile | 5 | 43000.9 | 20.293 | 18.979 | 17.26 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
