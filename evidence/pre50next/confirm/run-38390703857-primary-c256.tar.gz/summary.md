# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline | 5 | 41259.7 | 13.692 | 20.791 | 17.74 |
| etcd | 5 | 6047.8 | 74.614 | 164.843 | 264.17 |
| peer | 5 | 42380.9 | 12.627 | 20.996 | 17.80 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
