# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline-profile | 5 | 67259.1 | 8.757 | 12.240 | 10.97 |
| etcd-control | 5 | 5665.2 | 80.860 | 172.426 | 260.47 |
| peer-profile | 5 | 69273.6 | 9.163 | 12.532 | 10.98 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
