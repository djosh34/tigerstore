# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline | 5 | 21399.7 | 5.377 | 34.167 | 16.40 |
| etcd | 5 | 4350.2 | 28.249 | 224.000 | 269.76 |
| peer | 5 | 22282.0 | 5.213 | 34.500 | 16.35 |
| wake | 5 | 22255.9 | 5.031 | 33.333 | 16.39 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
