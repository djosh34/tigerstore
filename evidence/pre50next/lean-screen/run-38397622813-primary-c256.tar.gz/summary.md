# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline | 5 | 64561.6 | 7.715 | 13.667 | 11.18 |
| etcd | 5 | 5986.8 | 76.354 | 166.000 | 260.11 |
| peer | 5 | 66154.8 | 8.180 | 13.333 | 11.19 |
| wake | 5 | 64885.3 | 8.186 | 13.667 | 11.18 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
