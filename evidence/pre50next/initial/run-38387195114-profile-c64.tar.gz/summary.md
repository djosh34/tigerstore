# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline-control | 5 | 26465.9 | 5.377 | 31.955 | 21.60 |
| baseline-profile | 5 | 25170.0 | 5.473 | 32.142 | 21.57 |
| etcd-control | 5 | 5100.6 | 24.684 | 190.380 | 275.26 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
