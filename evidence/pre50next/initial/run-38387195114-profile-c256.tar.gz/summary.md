# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline-control | 5 | 42641.6 | 13.072 | 20.907 | 17.59 |
| baseline-profile | 5 | 39958.5 | 14.158 | 22.544 | 17.61 |
| etcd-control | 5 | 5751.8 | 79.906 | 173.347 | 264.02 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
