# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline-control | 5 | 60820.8 | 8.743 | 12.873 | 10.92 |
| baseline-profile | 5 | 61863.1 | 8.588 | 12.957 | 10.94 |
| etcd-control | 5 | 5585.8 | 82.562 | 176.148 | 260.35 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
