# Put results

Medians of per-run statistics. Profile controls and primary runs are separate.

| Variant | Reps | Put/s | p99 ms | Leader CPU us/Put | Leader allocations/Put |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline-control | 5 | 24652.8 | 4.643 | 29.873 | 16.30 |
| baseline-profile | 5 | 24631.4 | 4.657 | 30.334 | 16.33 |
| etcd-control | 5 | 5028.0 | 25.037 | 194.455 | 269.20 |

CPU comes from the generator worker interval through drain. Allocation, I/O and sync counters use the wider all-replica-fenced interval. Etcd syncs count WAL observations, not backend commits. Forced-GC retained heap is only available for Tigerstore.
