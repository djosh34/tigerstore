// Copyright 2016 The etcd Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package command

import (
	"fmt"
	"os"

	"google.golang.org/protobuf/proto"

	pb "go.etcd.io/etcd/api/v3/etcdserverpb"
	v3 "go.etcd.io/etcd/client/v3"
	"go.etcd.io/etcd/pkg/v3/cobrautl"
)

type pbPrinter struct{ printer }

func newPBPrinter() printer {
	return &pbPrinter{
		&printerRPC{newPrinterUnsupported("protobuf"), printPB},
	}
}

func (p *pbPrinter) Watch(r *v3.WatchResponse) {
	wr := &pb.WatchResponse{}
	if r != nil {
		wr = &pb.WatchResponse{
			Header:          r.Header,
			Events:          r.Events,
			CompactRevision: r.CompactRevision,
			Canceled:        r.Canceled,
			Created:         r.Created,
		}
	}
	printPB(wr)
}

func printPB(v any) {
	var b []byte
	var err error
	switch m := v.(type) {
	case proto.Message:
		b, err = proto.Marshal(m)
	default:
		cobrautl.ExitWithError(cobrautl.ExitBadFeature, fmt.Errorf("marshal unsupported for type %T (%v)", v, v))
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "%v\n", err)
		return
	}
	fmt.Print(string(b))
}
