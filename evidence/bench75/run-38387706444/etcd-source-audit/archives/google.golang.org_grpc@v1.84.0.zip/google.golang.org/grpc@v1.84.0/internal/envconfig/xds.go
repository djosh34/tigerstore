/*
 *
 * Copyright 2020 gRPC authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package envconfig

import (
	"os"
)

const (
	// XDSBootstrapFileNameEnv is the env variable to set bootstrap file name.
	// Do not use this and read from env directly. Its value is read and kept in
	// variable XDSBootstrapFileName.
	//
	// When both bootstrap FileName and FileContent are set, FileName is used.
	XDSBootstrapFileNameEnv = "GRPC_XDS_BOOTSTRAP"
	// XDSBootstrapFileContentEnv is the env variable to set bootstrap file
	// content. Do not use this and read from env directly. Its value is read
	// and kept in variable XDSBootstrapFileContent.
	//
	// When both bootstrap FileName and FileContent are set, FileName is used.
	XDSBootstrapFileContentEnv = "GRPC_XDS_BOOTSTRAP_CONFIG"
)

var (
	// XDSBootstrapFileName holds the name of the file which contains xDS
	// bootstrap configuration. Users can specify the location of the bootstrap
	// file by setting the environment variable "GRPC_XDS_BOOTSTRAP".
	//
	// When both bootstrap FileName and FileContent are set, FileName is used.
	XDSBootstrapFileName = os.Getenv(XDSBootstrapFileNameEnv)
	// XDSBootstrapFileContent holds the content of the xDS bootstrap
	// configuration. Users can specify the bootstrap config by setting the
	// environment variable "GRPC_XDS_BOOTSTRAP_CONFIG".
	//
	// When both bootstrap FileName and FileContent are set, FileName is used.
	XDSBootstrapFileContent = os.Getenv(XDSBootstrapFileContentEnv)

	// C2PResolverTestOnlyTrafficDirectorURI is the TD URI for testing.
	C2PResolverTestOnlyTrafficDirectorURI = os.Getenv("GRPC_TEST_ONLY_GOOGLE_C2P_RESOLVER_TRAFFIC_DIRECTOR_URI")

	// XDSDualstackEndpointsEnabled is true if gRPC should read the
	// "additional addresses" in the xDS endpoint resource.
	XDSDualstackEndpointsEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_DUALSTACK_ENDPOINTS", true)

	// XDSSystemRootCertsEnabled is true when xDS enabled gRPC clients can use
	// the system's default root certificates for TLS certificate validation.
	// For more details, see:
	// https://github.com/grpc/proposal/blob/master/A82-xds-system-root-certs.md.
	XDSSystemRootCertsEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_SYSTEM_ROOT_CERTS", false)

	// XDSSPIFFEEnabled controls if SPIFFE Bundle Maps can be used as roots of
	// trust.  For more details, see:
	// https://github.com/grpc/proposal/blob/master/A87-mtls-spiffe-support.md
	XDSSPIFFEEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_MTLS_SPIFFE", false)

	// XDSHTTPConnectEnabled controls support for dynamic HTTP CONNECT proxying
	// configured via the xDS control plane. For more details, see:
	// https://github.com/grpc/proposal/blob/master/A86-xds-http-connect.md
	XDSHTTPConnectEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_HTTP_CONNECT", false)

	// XDSBootstrapCallCredsEnabled controls if call credentials can be used in
	// xDS bootstrap configuration via the `call_creds` field. For more details,
	// see: https://github.com/grpc/proposal/blob/master/A97-xds-jwt-call-creds.md
	XDSBootstrapCallCredsEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_BOOTSTRAP_CALL_CREDS", false)

	// XDSSNIEnabled controls if gRPC should send SNI information in xDS
	// configured TLS handshakes. For more details, see:
	// https://github.com/grpc/proposal/blob/master/A101-SNI-setting-and-SNI-SAN-validation.md
	XDSSNIEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_SNI", false)

	// XDSORCAToLRSPropEnabled controls whether ORCA metrics are explicitly
	// filtered and prefix-propagated to the LRS server. For more details, see:
	// https://github.com/grpc/proposal/blob/master/A85-lrs-custom-metrics-changes.md
	XDSORCAToLRSPropEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_ORCA_LRS_PROPAGATION", true)

	// XDSClientExtProcEnabled indicates whether ExtProc filter is enabled on
	// the client side. For more details, see:
	// https://github.com/grpc/proposal/blob/master/A93-xds-ext-proc.md
	XDSClientExtProcEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_EXT_PROC_ON_CLIENT", false)

	// GCPAuthenticationFilterEnabled enables the xDS GCP Authentication
	// filter. For more details, see:
	// https://github.com/grpc/proposal/blob/master/A83-xds-gcp-authn-filter.md
	GCPAuthenticationFilterEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_GCP_AUTHENTICATION_FILTER", false)

	// XDSClientExtAuthzEnabled indicates whether the external authorization
	// filter is enabled on the client side. For more details, see:
	// https://github.com/grpc/proposal/blob/master/A92-xds-ext-authz.md
	XDSClientExtAuthzEnabled = boolFromEnv("GRPC_EXPERIMENTAL_XDS_EXT_AUTHZ_ON_CLIENT", false)
)
