// Copyright 2015 The etcd Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package raft

import (
	"fmt"
	"io"
	"os"
	"os/exec"
	"strings"
)

func diffu(a, b string) string {
	if a == b {
		return ""
	}
	aname, bname := mustTemp("base", a), mustTemp("other", b)
	defer os.Remove(aname)
	defer os.Remove(bname)
	cmd := exec.Command("diff", "-u", aname, bname)
	buf, err := cmd.CombinedOutput()
	if err != nil {
		if _, ok := err.(*exec.ExitError); ok {
			// do nothing
			return string(buf)
		}
		panic(err)
	}
	return string(buf)
}

func mustTemp(pre, body string) string {
	f, err := os.CreateTemp("", pre)
	if err != nil {
		panic(err)
	}
	_, err = io.Copy(f, strings.NewReader(body))
	if err != nil {
		panic(err)
	}
	f.Close()
	return f.Name()
}

func ltoa(l *raftLog) string {
	s := fmt.Sprintf("lastIndex: %d\n", l.lastIndex())
	s += fmt.Sprintf("applied:  %d\n", l.applied)
	s += fmt.Sprintf("applying:  %d\n", l.applying)
	for i, e := range l.allEntries() {
		// TODO: after migrating to protoc-gen-go, marsh entry using code like below,
		//  es, _ := proto.MarshalOptions{Deterministic: true}.Marshal(e)
		s += fmt.Sprintf("#%d: %+v\n", i, e.String())
	}
	return s
}
