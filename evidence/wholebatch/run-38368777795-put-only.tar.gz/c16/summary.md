# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 16 | admit | 9273.7 | 1.586 | 2.295 | 3.024 | 162.667 |
| 16 | etcd | 3646.3 | 4.193 | 6.695 | 10.300 | 421.333 |
| 16 | full | 9680.4 | 1.599 | 2.267 | 2.936 | 160.000 |
| 16 | main | 5701.8 | 2.702 | 3.888 | 5.409 | 246.000 |
| 16 | pool | 9118.3 | 1.722 | 2.358 | 2.865 | 169.667 |
| 16 | ring | 8711.4 | 1.721 | 2.414 | 3.118 | 169.333 |
| 16 | rpc | 9591.2 | 1.608 | 2.305 | 3.161 | 164.000 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 16 | admit | leader | 82.333 | 60.733 | 13228.9 | 4.131 |
| 16 | admit | follower1 | 43.333 | 19.456 | 3237.6 | 4.051 |
| 16 | admit | follower2 | 37.000 | 19.424 | 3236.9 | 4.161 |
| 16 | etcd | leader | 261.333 | 298.860 | 36054.9 | 4.547 |
| 16 | etcd | follower1 | 82.667 | 105.224 | 16264.2 | 4.733 |
| 16 | etcd | follower2 | 76.333 | 105.935 | 16305.2 | 4.640 |
| 16 | full | leader | 80.000 | 55.331 | 7530.3 | 4.082 |
| 16 | full | follower1 | 42.667 | 17.392 | 2160.0 | 3.999 |
| 16 | full | follower2 | 37.000 | 17.292 | 2156.0 | 4.120 |
| 16 | main | leader | 162.000 | 159.987 | 21463.5 | 4.395 |
| 16 | main | follower1 | 44.333 | 18.174 | 3185.2 | 3.935 |
| 16 | main | follower2 | 39.333 | 18.127 | 3182.9 | 3.975 |
| 16 | pool | leader | 90.000 | 46.027 | 5701.6 | 4.124 |
| 16 | pool | follower1 | 42.667 | 17.004 | 2148.2 | 3.957 |
| 16 | pool | follower2 | 37.000 | 16.993 | 2146.6 | 4.071 |
| 16 | ring | leader | 90.333 | 46.302 | 5712.4 | 4.124 |
| 16 | ring | follower1 | 42.333 | 17.221 | 2156.8 | 4.003 |
| 16 | ring | follower2 | 36.667 | 17.121 | 2152.9 | 4.079 |
| 16 | rpc | leader | 84.667 | 60.041 | 13193.1 | 4.257 |
| 16 | rpc | follower1 | 42.667 | 19.440 | 3239.6 | 4.189 |
| 16 | rpc | follower2 | 37.000 | 19.240 | 3231.0 | 4.231 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 16 | admit/rpc | 1.028 | 0.986 | 1.012 | 1.002 | 0.965 | 1.008 |
| 16 | full/admit | 1.044 | 0.949 | 0.907 | 0.601 | 0.968 | 0.957 |

| Clients | Variant | Leader GC accounting us/Put | Leader retained heap MiB | Core handoff sends/Put | Frontend controls/Put |
| ---: | --- | ---: | ---: | ---: | ---: |
| 16 | admit | 1.334 | 96.11 | 2.000 | 3.032 |
| 16 | etcd | nan | nan | nan | nan |
| 16 | full | 1.128 | 54.26 | 2.000 | 3.032 |
| 16 | main | 2.872 | 96.47 | 2.000 | nan |
| 16 | pool | 0.916 | 114.45 | 2.000 | 3.032 |
| 16 | ring | 0.472 | 242.39 | 2.000 | 3.032 |
| 16 | rpc | 1.322 | 96.50 | 2.000 | 3.032 |

GC CPU is runtime /cpu/classes/gc/total accounting, not sampled process CPU. Stock etcd does not expose this counter here.
Retained heap is after eight quiet seconds and forced GC, outside headline windows. It includes the retained log and history, plus reserved ring bytes.
Channel figures count specified successful sends, not runtime-wide channel operations. Core handoffs are admission plus reply delivery; frontend control sends are separate. grpc-go internals are not counted.
CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
