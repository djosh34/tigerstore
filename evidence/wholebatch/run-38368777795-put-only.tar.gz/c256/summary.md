# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 256 | admit | 38060.7 | 6.038 | 11.948 | 15.539 | 43.000 |
| 256 | etcd | 5834.1 | 42.013 | 65.508 | 78.440 | 233.667 |
| 256 | full | 39989.7 | 5.852 | 10.928 | 14.289 | 42.000 |
| 256 | main | 9649.1 | 25.030 | 43.239 | 53.674 | 122.667 |
| 256 | pool | 38283.0 | 6.033 | 11.484 | 15.454 | 41.000 |
| 256 | ring | 38023.2 | 6.126 | 11.524 | 13.730 | 42.667 |
| 256 | rpc | 33426.3 | 6.902 | 13.052 | 16.874 | 46.000 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 256 | admit | leader | 24.667 | 37.012 | 13678.0 | 36.364 |
| 256 | admit | follower1 | 9.333 | 8.660 | 2843.9 | 33.632 |
| 256 | admit | follower2 | 9.333 | 8.643 | 2843.7 | 34.762 |
| 256 | etcd | leader | 170.667 | 264.294 | 34826.3 | 15.306 |
| 256 | etcd | follower1 | 32.000 | 81.661 | 14802.0 | 48.387 |
| 256 | etcd | follower2 | 31.000 | 81.709 | 14680.4 | 45.732 |
| 256 | full | leader | 23.000 | 33.055 | 6895.4 | 30.364 |
| 256 | full | follower1 | 10.000 | 6.992 | 1806.5 | 28.463 |
| 256 | full | follower2 | 9.333 | 6.995 | 1804.7 | 29.940 |
| 256 | main | leader | 103.000 | 146.118 | 21882.0 | 10.997 |
| 256 | main | follower1 | 10.000 | 10.641 | 2918.1 | 40.323 |
| 256 | main | follower2 | 9.667 | 10.644 | 2918.2 | 40.000 |
| 256 | pool | leader | 25.000 | 24.826 | 4947.7 | 41.152 |
| 256 | pool | follower1 | 8.333 | 6.509 | 1769.6 | 36.408 |
| 256 | pool | follower2 | 8.000 | 6.506 | 1776.6 | 37.221 |
| 256 | ring | leader | 25.333 | 24.862 | 4953.0 | 40.214 |
| 256 | ring | follower1 | 9.000 | 6.536 | 1776.8 | 36.320 |
| 256 | ring | follower2 | 8.000 | 6.536 | 1777.4 | 37.175 |
| 256 | rpc | leader | 29.000 | 38.718 | 13628.5 | 46.875 |
| 256 | rpc | follower1 | 8.667 | 8.339 | 2826.4 | 42.135 |
| 256 | rpc | follower2 | 8.333 | 8.341 | 2826.5 | 42.076 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | admit/rpc | 1.140 | 0.954 | 0.982 | 1.004 | 0.915 | 0.933 |
| 256 | full/admit | 1.063 | 0.961 | 0.867 | 0.542 | 0.913 | 0.920 |

| Clients | Variant | Leader GC accounting us/Put | Leader retained heap MiB | Core handoff sends/Put | Frontend controls/Put |
| ---: | --- | ---: | ---: | ---: | ---: |
| 256 | admit | 1.350 | 97.31 | 1.015 | 1.169 |
| 256 | etcd | nan | nan | nan | nan |
| 256 | full | 1.011 | 55.30 | 1.021 | 1.164 |
| 256 | main | 4.410 | 101.47 | 2.000 | nan |
| 256 | pool | 0.926 | 115.17 | 1.012 | 1.173 |
| 256 | ring | 0.429 | 242.55 | 1.013 | 1.171 |
| 256 | rpc | 1.864 | 97.16 | 2.000 | 1.210 |

GC CPU is runtime /cpu/classes/gc/total accounting, not sampled process CPU. Stock etcd does not expose this counter here.
Retained heap is after eight quiet seconds and forced GC, outside headline windows. It includes the retained log and history, plus reserved ring bytes.
Channel figures count specified successful sends, not runtime-wide channel operations. Core handoffs are admission plus reply delivery; frontend control sends are separate. grpc-go internals are not counted.
CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
