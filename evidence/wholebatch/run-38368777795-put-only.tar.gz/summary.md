# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 16 | admit | 9273.7 | 1.586 | 2.295 | 3.024 | 162.667 |
| 16 | etcd | 3646.3 | 4.193 | 6.695 | 10.300 | 421.333 |
| 16 | full | 9680.4 | 1.599 | 2.267 | 2.936 | 160.000 |
| 16 | main | 5701.8 | 2.702 | 3.888 | 5.409 | 246.000 |
| 16 | pool | 9118.3 | 1.722 | 2.358 | 2.865 | 169.667 |
| 16 | ring | 8711.4 | 1.721 | 2.414 | 3.118 | 169.333 |
| 16 | rpc | 9591.2 | 1.608 | 2.305 | 3.161 | 164.000 |
| 64 | admit | 22876.1 | 2.590 | 4.677 | 7.248 | 74.000 |
| 64 | etcd | 4716.3 | 12.548 | 22.048 | 26.527 | 299.000 |
| 64 | full | 24127.7 | 2.495 | 4.215 | 5.888 | 69.000 |
| 64 | main | 8711.2 | 6.945 | 11.066 | 15.567 | 147.667 |
| 64 | pool | 22462.4 | 2.692 | 4.351 | 6.170 | 74.667 |
| 64 | ring | 22408.3 | 2.643 | 4.207 | 6.048 | 72.333 |
| 64 | rpc | 20542.9 | 2.913 | 4.766 | 7.585 | 79.333 |
| 256 | admit | 38060.7 | 6.038 | 11.948 | 15.539 | 43.000 |
| 256 | etcd | 5834.1 | 42.013 | 65.508 | 78.440 | 233.667 |
| 256 | full | 39989.7 | 5.852 | 10.928 | 14.289 | 42.000 |
| 256 | main | 9649.1 | 25.030 | 43.239 | 53.674 | 122.667 |
| 256 | pool | 38283.0 | 6.033 | 11.484 | 15.454 | 41.000 |
| 256 | ring | 38023.2 | 6.126 | 11.524 | 13.730 | 42.667 |
| 256 | rpc | 33426.3 | 6.902 | 13.052 | 16.874 | 46.000 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 16 | admit | leader | 82.333 | 60.733 | 13228.9 | 4.131 |
| 16 | admit | follower1 | 43.333 | 19.456 | 3237.6 | 4.051 |
| 16 | admit | follower2 | 37.000 | 19.424 | 3236.9 | 4.161 |
| 16 | etcd | leader | 261.333 | 298.860 | 36054.9 | 4.547 |
| 16 | etcd | follower1 | 82.667 | 105.224 | 16264.2 | 4.733 |
| 16 | etcd | follower2 | 76.333 | 105.935 | 16305.2 | 4.640 |
| 16 | full | leader | 80.000 | 55.331 | 7530.3 | 4.082 |
| 16 | full | follower1 | 42.667 | 17.392 | 2160.0 | 3.999 |
| 16 | full | follower2 | 37.000 | 17.292 | 2156.0 | 4.120 |
| 16 | main | leader | 162.000 | 159.987 | 21463.5 | 4.395 |
| 16 | main | follower1 | 44.333 | 18.174 | 3185.2 | 3.935 |
| 16 | main | follower2 | 39.333 | 18.127 | 3182.9 | 3.975 |
| 16 | pool | leader | 90.000 | 46.027 | 5701.6 | 4.124 |
| 16 | pool | follower1 | 42.667 | 17.004 | 2148.2 | 3.957 |
| 16 | pool | follower2 | 37.000 | 16.993 | 2146.6 | 4.071 |
| 16 | ring | leader | 90.333 | 46.302 | 5712.4 | 4.124 |
| 16 | ring | follower1 | 42.333 | 17.221 | 2156.8 | 4.003 |
| 16 | ring | follower2 | 36.667 | 17.121 | 2152.9 | 4.079 |
| 16 | rpc | leader | 84.667 | 60.041 | 13193.1 | 4.257 |
| 16 | rpc | follower1 | 42.667 | 19.440 | 3239.6 | 4.189 |
| 16 | rpc | follower2 | 37.000 | 19.240 | 3231.0 | 4.231 |
| 64 | admit | leader | 39.000 | 42.337 | 13498.5 | 13.699 |
| 64 | admit | follower1 | 18.667 | 10.885 | 2953.3 | 13.021 |
| 64 | admit | follower2 | 16.333 | 10.858 | 2958.5 | 13.333 |
| 64 | etcd | leader | 206.333 | 275.519 | 35790.6 | 10.929 |
| 64 | etcd | follower1 | 47.667 | 91.929 | 16151.1 | 15.408 |
| 64 | etcd | follower2 | 45.333 | 91.311 | 15905.2 | 15.496 |
| 64 | full | leader | 36.333 | 36.864 | 6962.6 | 13.774 |
| 64 | full | follower1 | 17.667 | 8.860 | 1884.6 | 13.245 |
| 64 | full | follower2 | 15.333 | 8.851 | 1884.5 | 13.724 |
| 64 | main | leader | 112.667 | 143.858 | 21963.5 | 15.890 |
| 64 | main | follower1 | 18.333 | 10.241 | 2931.8 | 14.402 |
| 64 | main | follower2 | 16.667 | 10.244 | 2930.2 | 14.361 |
| 64 | pool | leader | 40.667 | 28.882 | 5053.6 | 14.225 |
| 64 | pool | follower1 | 17.667 | 8.724 | 1880.1 | 13.216 |
| 64 | pool | follower2 | 16.000 | 8.692 | 1877.7 | 13.630 |
| 64 | ring | leader | 39.667 | 28.785 | 5045.0 | 14.252 |
| 64 | ring | follower1 | 17.000 | 8.698 | 1876.6 | 13.495 |
| 64 | ring | follower2 | 15.333 | 8.657 | 1873.1 | 13.618 |
| 64 | rpc | leader | 45.000 | 43.531 | 13556.0 | 14.500 |
| 64 | rpc | follower1 | 18.000 | 10.594 | 2945.5 | 13.587 |
| 64 | rpc | follower2 | 16.333 | 10.571 | 2945.3 | 13.812 |
| 256 | admit | leader | 24.667 | 37.012 | 13678.0 | 36.364 |
| 256 | admit | follower1 | 9.333 | 8.660 | 2843.9 | 33.632 |
| 256 | admit | follower2 | 9.333 | 8.643 | 2843.7 | 34.762 |
| 256 | etcd | leader | 170.667 | 264.294 | 34826.3 | 15.306 |
| 256 | etcd | follower1 | 32.000 | 81.661 | 14802.0 | 48.387 |
| 256 | etcd | follower2 | 31.000 | 81.709 | 14680.4 | 45.732 |
| 256 | full | leader | 23.000 | 33.055 | 6895.4 | 30.364 |
| 256 | full | follower1 | 10.000 | 6.992 | 1806.5 | 28.463 |
| 256 | full | follower2 | 9.333 | 6.995 | 1804.7 | 29.940 |
| 256 | main | leader | 103.000 | 146.118 | 21882.0 | 10.997 |
| 256 | main | follower1 | 10.000 | 10.641 | 2918.1 | 40.323 |
| 256 | main | follower2 | 9.667 | 10.644 | 2918.2 | 40.000 |
| 256 | pool | leader | 25.000 | 24.826 | 4947.7 | 41.152 |
| 256 | pool | follower1 | 8.333 | 6.509 | 1769.6 | 36.408 |
| 256 | pool | follower2 | 8.000 | 6.506 | 1776.6 | 37.221 |
| 256 | ring | leader | 25.333 | 24.862 | 4953.0 | 40.214 |
| 256 | ring | follower1 | 9.000 | 6.536 | 1776.8 | 36.320 |
| 256 | ring | follower2 | 8.000 | 6.536 | 1777.4 | 37.175 |
| 256 | rpc | leader | 29.000 | 38.718 | 13628.5 | 46.875 |
| 256 | rpc | follower1 | 8.667 | 8.339 | 2826.4 | 42.135 |
| 256 | rpc | follower2 | 8.333 | 8.341 | 2826.5 | 42.076 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 16 | admit/rpc | 1.028 | 0.986 | 1.012 | 1.002 | 0.965 | 1.008 |
| 16 | full/admit | 1.044 | 0.949 | 0.907 | 0.601 | 0.968 | 0.957 |
| 64 | admit/rpc | 1.136 | 0.929 | 0.990 | 0.998 | 0.983 | 1.015 |
| 64 | full/admit | 1.050 | 0.932 | 0.852 | 0.552 | 0.903 | 0.838 |
| 256 | admit/rpc | 1.140 | 0.954 | 0.982 | 1.004 | 0.915 | 0.933 |
| 256 | full/admit | 1.063 | 0.961 | 0.867 | 0.542 | 0.913 | 0.920 |

| Clients | Variant | Leader GC accounting us/Put | Leader retained heap MiB | Core handoff sends/Put | Frontend controls/Put |
| ---: | --- | ---: | ---: | ---: | ---: |
| 16 | admit | 1.334 | 96.11 | 2.000 | 3.032 |
| 16 | etcd | nan | nan | nan | nan |
| 16 | full | 1.128 | 54.26 | 2.000 | 3.032 |
| 16 | main | 2.872 | 96.47 | 2.000 | nan |
| 16 | pool | 0.916 | 114.45 | 2.000 | 3.032 |
| 16 | ring | 0.472 | 242.39 | 2.000 | 3.032 |
| 16 | rpc | 1.322 | 96.50 | 2.000 | 3.032 |
| 64 | admit | 1.443 | 97.70 | 1.019 | 1.559 |
| 64 | etcd | nan | nan | nan | nan |
| 64 | full | 0.939 | 55.53 | 1.018 | 1.560 |
| 64 | main | 3.071 | 98.73 | 2.000 | nan |
| 64 | pool | 0.974 | 115.47 | 1.015 | 1.552 |
| 64 | ring | 0.379 | 243.47 | 1.014 | 1.552 |
| 64 | rpc | 1.445 | 98.54 | 2.000 | 1.691 |
| 256 | admit | 1.350 | 97.31 | 1.015 | 1.169 |
| 256 | etcd | nan | nan | nan | nan |
| 256 | full | 1.011 | 55.30 | 1.021 | 1.164 |
| 256 | main | 4.410 | 101.47 | 2.000 | nan |
| 256 | pool | 0.926 | 115.17 | 1.012 | 1.173 |
| 256 | ring | 0.429 | 242.55 | 1.013 | 1.171 |
| 256 | rpc | 1.864 | 97.16 | 2.000 | 1.210 |

GC CPU is runtime /cpu/classes/gc/total accounting, not sampled process CPU. Stock etcd does not expose this counter here.
Retained heap is after eight quiet seconds and forced GC, outside headline windows. It includes the retained log and history, plus reserved ring bytes.
Channel figures count specified successful sends, not runtime-wide channel operations. Core handoffs are admission plus reply delivery; frontend control sends are separate. grpc-go internals are not counted.
CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
