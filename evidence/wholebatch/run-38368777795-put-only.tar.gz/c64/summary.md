# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 64 | admit | 22876.1 | 2.590 | 4.677 | 7.248 | 74.000 |
| 64 | etcd | 4716.3 | 12.548 | 22.048 | 26.527 | 299.000 |
| 64 | full | 24127.7 | 2.495 | 4.215 | 5.888 | 69.000 |
| 64 | main | 8711.2 | 6.945 | 11.066 | 15.567 | 147.667 |
| 64 | pool | 22462.4 | 2.692 | 4.351 | 6.170 | 74.667 |
| 64 | ring | 22408.3 | 2.643 | 4.207 | 6.048 | 72.333 |
| 64 | rpc | 20542.9 | 2.913 | 4.766 | 7.585 | 79.333 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 64 | admit | leader | 39.000 | 42.337 | 13498.5 | 13.699 |
| 64 | admit | follower1 | 18.667 | 10.885 | 2953.3 | 13.021 |
| 64 | admit | follower2 | 16.333 | 10.858 | 2958.5 | 13.333 |
| 64 | etcd | leader | 206.333 | 275.519 | 35790.6 | 10.929 |
| 64 | etcd | follower1 | 47.667 | 91.929 | 16151.1 | 15.408 |
| 64 | etcd | follower2 | 45.333 | 91.311 | 15905.2 | 15.496 |
| 64 | full | leader | 36.333 | 36.864 | 6962.6 | 13.774 |
| 64 | full | follower1 | 17.667 | 8.860 | 1884.6 | 13.245 |
| 64 | full | follower2 | 15.333 | 8.851 | 1884.5 | 13.724 |
| 64 | main | leader | 112.667 | 143.858 | 21963.5 | 15.890 |
| 64 | main | follower1 | 18.333 | 10.241 | 2931.8 | 14.402 |
| 64 | main | follower2 | 16.667 | 10.244 | 2930.2 | 14.361 |
| 64 | pool | leader | 40.667 | 28.882 | 5053.6 | 14.225 |
| 64 | pool | follower1 | 17.667 | 8.724 | 1880.1 | 13.216 |
| 64 | pool | follower2 | 16.000 | 8.692 | 1877.7 | 13.630 |
| 64 | ring | leader | 39.667 | 28.785 | 5045.0 | 14.252 |
| 64 | ring | follower1 | 17.000 | 8.698 | 1876.6 | 13.495 |
| 64 | ring | follower2 | 15.333 | 8.657 | 1873.1 | 13.618 |
| 64 | rpc | leader | 45.000 | 43.531 | 13556.0 | 14.500 |
| 64 | rpc | follower1 | 18.000 | 10.594 | 2945.5 | 13.587 |
| 64 | rpc | follower2 | 16.333 | 10.571 | 2945.3 | 13.812 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 64 | admit/rpc | 1.136 | 0.929 | 0.990 | 0.998 | 0.983 | 1.015 |
| 64 | full/admit | 1.050 | 0.932 | 0.852 | 0.552 | 0.903 | 0.838 |

| Clients | Variant | Leader GC accounting us/Put | Leader retained heap MiB | Core handoff sends/Put | Frontend controls/Put |
| ---: | --- | ---: | ---: | ---: | ---: |
| 64 | admit | 1.443 | 97.70 | 1.019 | 1.559 |
| 64 | etcd | nan | nan | nan | nan |
| 64 | full | 0.939 | 55.53 | 1.018 | 1.560 |
| 64 | main | 3.071 | 98.73 | 2.000 | nan |
| 64 | pool | 0.974 | 115.47 | 1.015 | 1.552 |
| 64 | ring | 0.379 | 243.47 | 1.014 | 1.552 |
| 64 | rpc | 1.445 | 98.54 | 2.000 | 1.691 |

GC CPU is runtime /cpu/classes/gc/total accounting, not sampled process CPU. Stock etcd does not expose this counter here.
Retained heap is after eight quiet seconds and forced GC, outside headline windows. It includes the retained log and history, plus reserved ring bytes.
Channel figures count specified successful sends, not runtime-wide channel operations. Core handoffs are admission plus reply delivery; frontend control sends are separate. grpc-go internals are not counted.
CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
