# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 64 | admit | 25579.0 | 2.329 | 4.064 | 5.940 | 66.000 |
| 64 | etcd | 5399.2 | 11.186 | 19.291 | 22.992 | 267.667 |
| 64 | full | 26685.1 | 2.235 | 3.815 | 5.486 | 61.333 |
| 64 | main | 9058.4 | 6.600 | 10.408 | 15.813 | 137.000 |
| 64 | pool | 24450.3 | 2.460 | 3.943 | 5.562 | 65.333 |
| 64 | ring | 23847.7 | 2.476 | 4.119 | 5.633 | 66.667 |
| 64 | rpc | 22687.0 | 2.642 | 4.373 | 7.014 | 71.000 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 64 | admit | leader | 35.000 | 42.049 | 13515.8 | 14.479 |
| 64 | admit | follower1 | 16.667 | 10.770 | 2954.4 | 13.908 |
| 64 | admit | follower2 | 14.333 | 10.736 | 2952.5 | 14.313 |
| 64 | etcd | leader | 182.667 | 275.751 | 36107.6 | 12.376 |
| 64 | etcd | follower1 | 43.667 | 92.116 | 16201.3 | 16.456 |
| 64 | etcd | follower2 | 41.000 | 92.626 | 16236.6 | 16.304 |
| 64 | full | leader | 32.333 | 36.732 | 6953.4 | 14.599 |
| 64 | full | follower1 | 15.333 | 8.853 | 1883.1 | 14.409 |
| 64 | full | follower2 | 13.333 | 8.831 | 1883.9 | 15.198 |
| 64 | main | leader | 105.667 | 143.894 | 21980.2 | 16.120 |
| 64 | main | follower1 | 16.667 | 10.275 | 2932.7 | 14.486 |
| 64 | main | follower2 | 14.667 | 10.275 | 2936.8 | 14.521 |
| 64 | pool | leader | 36.000 | 28.690 | 5047.3 | 14.528 |
| 64 | pool | follower1 | 16.000 | 8.626 | 1874.5 | 13.819 |
| 64 | pool | follower2 | 13.667 | 8.615 | 1874.0 | 14.171 |
| 64 | ring | leader | 36.333 | 28.783 | 5052.5 | 14.423 |
| 64 | ring | follower1 | 16.333 | 8.681 | 1876.1 | 13.787 |
| 64 | ring | follower2 | 14.000 | 8.652 | 1874.2 | 14.012 |
| 64 | rpc | leader | 40.333 | 43.438 | 13556.5 | 14.963 |
| 64 | rpc | follower1 | 16.333 | 10.530 | 2943.5 | 14.025 |
| 64 | rpc | follower2 | 14.333 | 10.521 | 2942.3 | 14.131 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 64 | admit/rpc | 1.146 | 0.924 | 0.986 | 1.000 | 0.929 | 0.892 |
| 64 | full/admit | 1.071 | 0.923 | 0.853 | 0.552 | 0.952 | 0.934 |

| Clients | Variant | Leader GC accounting us/Put | Leader retained heap MiB | Core handoff sends/Put | Frontend controls/Put |
| ---: | --- | ---: | ---: | ---: | ---: |
| 64 | admit | 1.276 | 99.01 | 1.018 | 1.559 |
| 64 | etcd | nan | nan | nan | nan |
| 64 | full | 0.783 | 55.44 | 1.018 | 1.563 |
| 64 | main | 2.992 | 98.98 | 2.000 | nan |
| 64 | pool | 0.810 | 115.44 | 1.012 | 1.557 |
| 64 | ring | 0.374 | 243.47 | 1.014 | 1.554 |
| 64 | rpc | 1.292 | 97.93 | 2.000 | 1.708 |

GC CPU is runtime /cpu/classes/gc/total accounting, not sampled process CPU. Stock etcd does not expose this counter here.
Retained heap is after eight quiet seconds and forced GC, outside headline windows. It includes the retained log and history, plus reserved ring bytes.
Channel figures count specified successful sends, not runtime-wide channel operations. Core handoffs are admission plus reply delivery; frontend control sends are separate. grpc-go internals are not counted.
CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
