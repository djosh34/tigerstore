# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 16 | admit | 8798.7 | 1.771 | 2.493 | 3.329 | 186.333 |
| 16 | etcd | 3444.6 | 4.196 | 6.922 | 11.127 | 420.000 |
| 16 | full | 9751.5 | 1.597 | 2.242 | 2.916 | 165.000 |
| 16 | main | 5708.1 | 2.695 | 3.815 | 5.728 | 245.333 |
| 16 | pool | 9051.9 | 1.733 | 2.367 | 2.829 | 177.667 |
| 16 | ring | 9077.1 | 1.738 | 2.367 | 2.838 | 177.667 |
| 16 | rpc | 9540.4 | 1.634 | 2.267 | 3.025 | 167.667 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 16 | admit | leader | 92.333 | 62.162 | 13238.6 | 3.837 |
| 16 | admit | follower1 | 51.000 | 20.269 | 3267.4 | 3.788 |
| 16 | admit | follower2 | 43.000 | 20.146 | 3262.6 | 3.864 |
| 16 | etcd | leader | 260.667 | 299.550 | 36101.3 | 4.541 |
| 16 | etcd | follower1 | 83.000 | 105.835 | 16293.6 | 4.652 |
| 16 | etcd | follower2 | 76.333 | 105.822 | 16349.6 | 4.623 |
| 16 | full | leader | 81.667 | 56.609 | 7587.2 | 3.911 |
| 16 | full | follower1 | 45.000 | 18.214 | 2194.6 | 3.848 |
| 16 | full | follower2 | 38.333 | 18.110 | 2191.3 | 3.894 |
| 16 | main | leader | 161.333 | 160.373 | 21473.6 | 4.351 |
| 16 | main | follower1 | 44.667 | 18.267 | 3189.4 | 3.909 |
| 16 | main | follower2 | 39.667 | 18.240 | 3188.3 | 3.936 |
| 16 | pool | leader | 93.667 | 47.575 | 5768.7 | 3.876 |
| 16 | pool | follower1 | 45.333 | 17.926 | 2182.5 | 3.717 |
| 16 | pool | follower2 | 38.667 | 17.807 | 2177.8 | 3.820 |
| 16 | ring | leader | 93.667 | 47.347 | 5759.1 | 3.965 |
| 16 | ring | follower1 | 45.000 | 17.679 | 2174.1 | 3.778 |
| 16 | ring | follower2 | 39.000 | 17.590 | 2170.7 | 3.943 |
| 16 | rpc | leader | 85.667 | 60.476 | 13195.2 | 4.023 |
| 16 | rpc | follower1 | 44.333 | 19.466 | 3237.7 | 3.952 |
| 16 | rpc | follower2 | 37.667 | 19.396 | 3235.1 | 4.030 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 16 | admit/rpc | 0.989 | 1.045 | 1.032 | 1.005 | 1.023 | 1.052 |
| 16 | full/admit | 1.086 | 0.927 | 0.901 | 0.605 | 0.912 | 0.872 |

| Clients | Variant | Leader GC accounting us/Put | Leader retained heap MiB | Core handoff sends/Put | Frontend controls/Put |
| ---: | --- | ---: | ---: | ---: | ---: |
| 16 | admit | 1.537 | 96.38 | 2.000 | 3.033 |
| 16 | etcd | nan | nan | nan | nan |
| 16 | full | 1.022 | 54.28 | 2.000 | 3.033 |
| 16 | main | 3.005 | 96.69 | 2.000 | nan |
| 16 | pool | 0.823 | 114.38 | 2.000 | 3.033 |
| 16 | ring | 0.481 | 242.29 | 2.000 | 3.033 |
| 16 | rpc | 1.415 | 96.75 | 2.000 | 3.033 |

GC CPU is runtime /cpu/classes/gc/total accounting, not sampled process CPU. Stock etcd does not expose this counter here.
Retained heap is after eight quiet seconds and forced GC, outside headline windows. It includes the retained log and history, plus reserved ring bytes.
Channel figures count specified successful sends, not runtime-wide channel operations. Core handoffs are admission plus reply delivery; frontend control sends are separate. grpc-go internals are not counted.
CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
