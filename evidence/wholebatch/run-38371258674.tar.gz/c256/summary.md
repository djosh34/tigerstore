# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 256 | admit | 40757.5 | 5.550 | 11.134 | 13.011 | 41.000 |
| 256 | etcd | 5919.3 | 42.080 | 63.639 | 78.338 | 230.667 |
| 256 | full | 42030.0 | 5.508 | 10.700 | 12.918 | 40.000 |
| 256 | main | 9569.7 | 24.869 | 42.523 | 54.652 | 120.000 |
| 256 | pool | 38353.9 | 6.014 | 11.667 | 14.069 | 40.667 |
| 256 | ring | 39953.3 | 5.858 | 10.965 | 13.262 | 39.333 |
| 256 | rpc | 34743.3 | 6.599 | 13.022 | 17.170 | 44.000 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 256 | admit | leader | 23.333 | 36.974 | 13661.8 | 37.783 |
| 256 | admit | follower1 | 9.000 | 8.639 | 2848.7 | 34.522 |
| 256 | admit | follower2 | 8.333 | 8.644 | 2848.8 | 35.377 |
| 256 | etcd | leader | 168.333 | 264.778 | 34829.2 | 14.500 |
| 256 | etcd | follower1 | 31.333 | 82.543 | 14849.6 | 44.577 |
| 256 | etcd | follower2 | 30.667 | 81.763 | 14605.4 | 45.732 |
| 256 | full | leader | 22.333 | 32.790 | 6870.8 | 32.644 |
| 256 | full | follower1 | 9.333 | 6.824 | 1793.5 | 30.864 |
| 256 | full | follower2 | 8.333 | 6.823 | 1793.6 | 31.813 |
| 256 | main | leader | 102.000 | 144.774 | 21902.1 | 13.089 |
| 256 | main | follower1 | 9.333 | 10.181 | 2929.3 | 41.152 |
| 256 | main | follower2 | 8.667 | 10.185 | 2922.3 | 40.872 |
| 256 | pool | leader | 24.667 | 24.792 | 4936.5 | 42.076 |
| 256 | pool | follower1 | 8.333 | 6.490 | 1769.2 | 37.453 |
| 256 | pool | follower2 | 7.333 | 6.488 | 1764.3 | 38.314 |
| 256 | ring | leader | 24.000 | 24.764 | 4937.2 | 42.614 |
| 256 | ring | follower1 | 8.000 | 6.473 | 1769.8 | 38.119 |
| 256 | ring | follower2 | 7.667 | 6.473 | 1766.3 | 39.012 |
| 256 | rpc | leader | 28.000 | 38.744 | 13601.4 | 46.584 |
| 256 | rpc | follower1 | 8.333 | 8.355 | 2834.6 | 42.614 |
| 256 | rpc | follower2 | 8.000 | 8.354 | 2824.4 | 42.918 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | admit/rpc | 1.181 | 0.931 | 0.974 | 1.005 | 0.855 | 0.771 |
| 256 | full/admit | 1.027 | 0.967 | 0.855 | 0.540 | 0.958 | 0.993 |

| Clients | Variant | Leader GC accounting us/Put | Leader retained heap MiB | Core handoff sends/Put | Frontend controls/Put |
| ---: | --- | ---: | ---: | ---: | ---: |
| 256 | admit | 1.278 | 101.59 | 1.013 | 1.171 |
| 256 | etcd | nan | nan | nan | nan |
| 256 | full | 1.009 | 54.97 | 1.017 | 1.165 |
| 256 | main | 4.450 | 100.87 | 2.000 | nan |
| 256 | pool | 1.178 | 115.00 | 1.011 | 1.173 |
| 256 | ring | 0.395 | 243.12 | 1.010 | 1.172 |
| 256 | rpc | 1.611 | 98.75 | 2.000 | 1.211 |

GC CPU is runtime /cpu/classes/gc/total accounting, not sampled process CPU. Stock etcd does not expose this counter here.
Retained heap is after eight quiet seconds and forced GC, outside headline windows. It includes the retained log and history, plus reserved ring bytes.
Channel figures count specified successful sends, not runtime-wide channel operations. Core handoffs are admission plus reply delivery; frontend control sends are separate. grpc-go internals are not counted.
CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
