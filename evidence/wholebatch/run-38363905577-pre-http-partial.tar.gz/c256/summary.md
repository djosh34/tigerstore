# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 256 | admit | 43242.8 | 5.273 | 10.584 | 13.172 | 38.333 |
| 256 | etcd | 6215.0 | 39.917 | 61.152 | 73.384 | 219.167 |
| 256 | full | 45467.4 | 5.103 | 9.916 | 11.931 | 37.167 |
| 256 | main | 10094.5 | 23.864 | 41.327 | 53.567 | 117.167 |
| 256 | native | 28089.5 | 8.405 | 15.176 | 21.340 | 49.333 |
| 256 | native-tuned | 29419.3 | 8.010 | 14.406 | 20.849 | 47.000 |
| 256 | rpc | 34999.0 | 6.640 | 12.410 | 17.321 | 42.500 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 256 | admit | leader | 21.667 | 36.726 | 13457.4 | 38.536 |
| 256 | admit | follower1 | 8.667 | 8.458 | 2853.0 | 35.608 |
| 256 | admit | follower2 | 7.833 | 8.456 | 2852.9 | 36.832 |
| 256 | etcd | leader | 160.500 | 263.851 | 34719.6 | 15.263 |
| 256 | etcd | follower1 | 29.500 | 80.981 | 14622.1 | 47.431 |
| 256 | etcd | follower2 | 28.500 | 81.474 | 14700.3 | 46.261 |
| 256 | full | leader | 20.667 | 32.546 | 6664.8 | 33.956 |
| 256 | full | follower1 | 8.833 | 6.649 | 1785.8 | 31.830 |
| 256 | full | follower2 | 7.667 | 6.621 | 1785.5 | 32.698 |
| 256 | main | leader | 98.833 | 147.268 | 21736.8 | 9.473 |
| 256 | main | follower1 | 9.500 | 10.980 | 2949.9 | 40.900 |
| 256 | main | follower2 | 8.667 | 10.984 | 2949.7 | 41.124 |
| 256 | native | leader | 35.000 | 73.203 | 14930.4 | 42.614 |
| 256 | native | follower1 | 7.500 | 8.220 | 2819.8 | 48.232 |
| 256 | native | follower2 | 7.000 | 8.219 | 2819.6 | 49.221 |
| 256 | native-tuned | leader | 32.833 | 72.455 | 14950.8 | 52.724 |
| 256 | native-tuned | follower1 | 7.333 | 8.051 | 2825.8 | 47.059 |
| 256 | native-tuned | follower2 | 7.000 | 8.057 | 2825.2 | 46.985 |
| 256 | rpc | leader | 27.667 | 38.388 | 13434.4 | 49.628 |
| 256 | rpc | follower1 | 7.667 | 8.111 | 2823.5 | 44.053 |
| 256 | rpc | follower2 | 7.000 | 8.111 | 2817.2 | 43.988 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | admit/rpc | 1.236 | 0.906 | 0.981 | 1.004 | 0.858 | 0.775 |
| 256 | full/admit | 1.051 | 0.965 | 0.854 | 0.534 | 0.938 | 0.906 |

CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
