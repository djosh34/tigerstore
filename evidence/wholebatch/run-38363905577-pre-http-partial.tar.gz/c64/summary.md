# Wholebatch runner medians

Five repetitions per variant in the same job. 16 connections, 1 KiB Put, 4,096 keys, leader-only.
Leader CPU 0, followers 1 and 2, generator 3. Servers GOMAXPROCS=2. Generator GOMAXPROCS=1.
These are closed-loop capacity runs with counting-only instrumentation, not profiles.

| Clients | Variant | Put/s | p50 ms | p95 ms | p99 ms | Total server CPU us/op |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 64 | admit | 24831.4 | 2.415 | 4.129 | 5.991 | 66.333 |
| 64 | etcd | 5302.8 | 11.241 | 19.006 | 23.315 | 264.833 |
| 64 | full | 26377.5 | 2.270 | 3.918 | 5.538 | 64.000 |
| 64 | main | 9187.2 | 6.604 | 10.089 | 15.371 | 137.333 |
| 64 | native | 17957.4 | 3.382 | 5.177 | 8.559 | 84.500 |
| 64 | native-tuned | 19307.5 | 3.141 | 4.887 | 8.042 | 79.500 |
| 64 | rpc | 22142.2 | 2.716 | 4.334 | 7.050 | 73.167 |

| Clients | Variant | Role | CPU us/op | Allocs/op | Bytes/op | Puts/file-fsync |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 64 | admit | leader | 34.833 | 42.019 | 13330.3 | 14.181 |
| 64 | admit | follower1 | 16.667 | 10.741 | 2962.1 | 13.815 |
| 64 | admit | follower2 | 14.833 | 10.706 | 2960.8 | 14.218 |
| 64 | etcd | leader | 181.333 | 274.640 | 35637.0 | 11.291 |
| 64 | etcd | follower1 | 43.167 | 90.212 | 15703.6 | 16.159 |
| 64 | etcd | follower2 | 41.167 | 91.051 | 15875.5 | 15.794 |
| 64 | full | leader | 32.833 | 36.751 | 6772.6 | 14.065 |
| 64 | full | follower1 | 16.500 | 8.807 | 1894.3 | 13.854 |
| 64 | full | follower2 | 14.333 | 8.788 | 1891.3 | 14.058 |
| 64 | main | leader | 105.500 | 143.583 | 21950.5 | 16.021 |
| 64 | main | follower1 | 16.667 | 10.076 | 2936.1 | 14.538 |
| 64 | main | follower2 | 15.167 | 10.075 | 2934.3 | 14.500 |
| 64 | native | leader | 52.833 | 78.214 | 14974.2 | 15.306 |
| 64 | native | follower1 | 16.667 | 10.295 | 2939.3 | 14.238 |
| 64 | native | follower2 | 15.000 | 10.294 | 2938.3 | 14.358 |
| 64 | native-tuned | leader | 48.000 | 77.770 | 14945.0 | 14.731 |
| 64 | native-tuned | follower1 | 16.667 | 10.415 | 2945.8 | 13.696 |
| 64 | native-tuned | follower2 | 15.000 | 10.410 | 2943.4 | 13.787 |
| 64 | rpc | leader | 41.000 | 43.334 | 13373.4 | 14.688 |
| 64 | rpc | follower1 | 16.833 | 10.443 | 2952.9 | 13.931 |
| 64 | rpc | follower2 | 15.000 | 10.427 | 2950.7 | 14.088 |

Stage ratios divide the later stage by the earlier stage within each repetition, then take the median ratio.
| Clients | Stages | Put/s ratio | Total CPU/op ratio | Allocs/op ratio | Bytes/op ratio | p95 ratio | p99 ratio |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 64 | admit/rpc | 1.121 | 0.917 | 0.989 | 0.998 | 0.942 | 0.859 |
| 64 | full/admit | 1.070 | 0.952 | 0.855 | 0.549 | 0.930 | 0.935 |

CPU is process user+system time from /proc, not owner-goroutine CPU.
CPU and allocation windows do not wait for follower catch-up. Follower cost can fall outside those windows.
Allocation counters bracket the CPU window and include small debug scrape overhead. They count all process allocations, not retained bytes.
Fsync deltas enclose the fully applied cohort on all nodes. etcd also fences on its post-WAL.Save committed gauge.
Tigerstore file syncs exclude directory syncs. etcd counts WAL fsync observations; backend commits are separate in runs.csv.
Medians are computed independently. paired.csv contains per-repetition candidate/baseline ratios.
